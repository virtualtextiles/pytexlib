TexMind Textile Viewer 
(c) TexMind UG (haftungsbeschränkt), 2019        www.texmind.com

What is TexMind Textile Viewer Free Edition?
******************
TexMind Textile Viewer is a free 3D viewer for textile structures.
It visualizes structures in the native format of the TexMind Suite (txm), and can import the files of TexGen, Wisetex and ReCo (Renkens Consulting Text Based Text File Format) too.

It is running under  MS Windows environment. 
MacOS and Linux Versions are under testing and will be available very soon, too, check the www.texmind.com page for these.

License
******************
TexMind Textile Viewer is FREEWARE!
You can use it for teaching, learning, you can send it to your customers so that they can see your txm files. 
You can NOT sell it or ask for any monetary equivalent for it.

******************
TexMind Textile Viewer Pro 
TexMind Textile Viewer Pro is an extended, proprietary version of the TexMind Viewer with integrated FEM- and other exporters. It is integrated in all main TexMind software packages, but can be requested as separate convertor, too.

-------------------------------------------------------------------------------
Authors:
******************
Yordan Kyosev, info@texmind.com, info@kyosev.com
Roberto Garrido

The TexMind software and all the accompanying materials is an intellectual property of the authors. It is prohibited to copy the software manuals or any of their part without the written permission of the TexMind UG.

-------------------------------------------------------------------------------

How to install:
******************
Just start the exe. No installation needed. No administrator rights.
If you like to have icon and assigned file ending to the application, then use the setup File.
	
Web site:
******************
TexMind official site:
	www.texmind.com



Disclaimer of Warranty
----------------------
The TexMind software is provided "as-is". 
No warranty of any kind is expressed or implied. 

This software and the accompanying files are sold "as is" and without warranties as to performance or any other warranties whether expressed or implied, including but not limited to implied warranties of fitness for a particular purpose, with respect to the software, the accompanying manuals and written materials. In no event shall TexMind UG be liable for any other damages whatsoever arising out of the use of or inability to use the TexMind software. The user must assume the entire risk of using the program.

Technical support	 
--------------------------------------------------------------
We provide e-mail support:
info@texmind.com
support@texmind.com

--------------------------------------------------------------
(c) TexMind UG (haftungsbeschränkt), 2019        www.texmind.com



Licenses
This software uses VTK and WxWidgets. These are distributed under the following licenses

/*=========================================================================

  Program:   Visualization Toolkit
  Module:    Copyright.txt

Copyright (c) 1993-2008 Ken Martin, Will Schroeder, Bill Lorensen
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 * Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

 * Neither name of Ken Martin, Will Schroeder, or Bill Lorensen nor the names
   of any contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS''
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=========================================================================*/
                wxWindows Library Licence, Version 3.1
                ======================================

  Copyright (C) 1998-2005 Julian Smart, Robert Roebling et al

  Everyone is permitted to copy and distribute verbatim copies
  of this licence document, but changing it is not allowed.

                       WXWINDOWS LIBRARY LICENCE
     TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
  
  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Library General Public Licence as published by
  the Free Software Foundation; either version 2 of the Licence, or (at
  your option) any later version.
  
  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library
  General Public Licence for more details.

  You should have received a copy of the GNU Library General Public Licence
  along with this software, usually in a file named COPYING.LIB.  If not,
  write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA 02111-1307 USA.

  EXCEPTION NOTICE

  1. As a special exception, the copyright holders of this library give
  permission for additional uses of the text contained in this release of
  the library as licenced under the wxWindows Library Licence, applying
  either version 3.1 of the Licence, or (at your option) any later version of
  the Licence as published by the copyright holders of version
  3.1 of the Licence document.

  2. The exception is that you may use, copy, link, modify and distribute
  under your own terms, binary object code versions of works based
  on the Library.

  3. If you copy code from files distributed under the terms of the GNU
  General Public Licence or the GNU Library General Public Licence into a
  copy of this library, as this licence permits, the exception does not
  apply to the code that you add in this way.  To avoid misleading anyone as
  to the status of such modified files, you must delete this exception
  notice from such code and/or adjust the licensing conditions notice
  accordingly.

  4. If you write modifications of your own for this library, it is your
  choice whether to permit this exception to apply to your modifications. 
  If you do not wish that, you must delete the exception notice from such
  code and/or adjust the licensing conditions notice accordingly.

 

